﻿using System;
using System.Data.Entity;
using $rootNamespace$.Models;

// TODO: Alter DbContext class to implement this interface and change
// each DbSet property to IDbSet

namespace $rootnamespace$
{
    // TODO: Rename IDatabaseContext
    public interface IDatabaseContext
    {
        // TODO: Add IDbSet<Entity> properties for each entity set on the DbContext class
        //IDbSet<Entit> Entities { get; set; }
    }
}
