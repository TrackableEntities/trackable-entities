﻿using System;
using System.Data.Entity;

// TODO: Alter DbContext class to implement this interface and change
// each DbSet property to IDbSet

namespace $rootnamespace$
{
    public interface $safeitemname$
    {
        // TODO: Add IDbSet<Entity> properties for each entity set on the DbContext class
        //IDbSet<Entity> Entities { get; set; }
    }
}
