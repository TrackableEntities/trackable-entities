﻿using System;
using TrackableEntities.Patterns;

namespace $rootnamespace$
{
    // TODO: Rename IExampleUnitOfWork
    public interface IExampleUnitOfWork : IUnitOfWork, IUnitOfWorkAsync
    {
        // TODO: Add read-only properties for each entity repository interface
        //IEntityRepository EntityRepository { get; }
    }
}
