﻿using System;
using TrackableEntities.Patterns;

namespace $rootnamespace$
{
    public interface $safeitemname$ : IUnitOfWork, IUnitOfWorkAsync
    {
        // TODO: Add read-only properties for each entity repository interface
        //IEntityRepository EntityRepository { get; }
    }
}
