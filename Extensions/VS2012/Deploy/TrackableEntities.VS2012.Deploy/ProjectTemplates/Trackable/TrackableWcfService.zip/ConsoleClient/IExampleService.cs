﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Threading.Tasks;
//using $saferootprojectname$.Client.Entities.Models;

// Use this example as a guide for copying the service contract from Service.Core
// after adding a Trackable WCF Service Type.

/* 
namespace $safeprojectname$
{
    [ServiceContract(Namespace = "urn:trackable-entities:service")]
    public interface IExampleService
    {
        [OperationContract(Name = "GetProducts")]
        Task<IEnumerable<Product>> GetProductsAsync();

        [OperationContract(Name = "GetProduct")]
        Task<Product> GetProductAsync(int id);

        [OperationContract(Name = "UpdateProduct")]
        Task<Product> UpdateProductAsync(Product entity);

        [OperationContract(Name = "CreateProduct")]
        Task<Product> CreateProductAsync(Product entity);

        [OperationContract(Name = "DeleteProduct")]
        Task<bool> DeleteProductAsync(int id);
    }
}
*/
